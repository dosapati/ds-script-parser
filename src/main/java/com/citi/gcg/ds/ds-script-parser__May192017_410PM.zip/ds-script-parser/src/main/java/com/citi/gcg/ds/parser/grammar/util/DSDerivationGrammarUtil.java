/**
 * 
 */
package com.citi.gcg.ds.parser.grammar.util;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Set;
import java.util.Map.Entry;

import org.antlr.v4.runtime.ANTLRInputStream;
import org.antlr.v4.runtime.BailErrorStrategy;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarLexer;
import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarParser;
import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarParser.NameContext;
import com.citi.gcg.ds.parser.listener.DescriptiveErrorListener;
import com.citi.gcg.ds.parser.visitor.DSDerivationCustomVisitor;
import com.citi.gcg.ds.util.FilesUtil;
import com.citi.gcg.rh.beans.RHExpression;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


/**
 * @author dosapati
 *
 */
public class DSDerivationGrammarUtil {
	
	private static Logger log = LoggerFactory.getLogger(DSDerivationGrammarUtil.class);
	
	final static Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();

	
	public static void main(String[] args) throws Exception {
		
		String s1 = "If IsNull(Tfm_Standardize.CHRG_OFF_DT) then '' else UpCase(DateToString(Tfm_Standardize.CHRG_OFF_DT,'%dd%mmm%yyyy'))";
		String s2 = "If IsNull(Tfm_Standardize.CHRG_OFF_DT) then '' ";
		String s3 = "Tfm_Standardize.REPORTING_PERIOD [1,6]";
		String s4 = "Tfm_Standardize.ACCOUNT_NUMBER";
		String s = "'0.0'";
		
		String drStmt = "If IsNull(Lnk_Nxg_Data.ORA633) then '' else If Index(DecimalToString(Lnk_Nxg_Data.ORA633,\"suppress_zero\"), '.',1)=0 THEN \n" + 
				"DecimalToString(Lnk_Nxg_Data.ORA633,\"suppress_zero\") : '.0' ELSE DecimalToString(Lnk_Nxg_Data.ORA633,\"suppress_zero\")";
		
		parseDerivation(s4);
		
		

	}
	
	public static LinkedList<RHExpression> parseDerivation(String derivationStmt,boolean printTree) throws Exception {
		
		ParseTree tree = buildParseTree(derivationStmt,printTree);		
		if(StringUtils.startsWithIgnoreCase(derivationStmt, "NullToValue")){
			String newExpr = "If IsNull(%s) then %s else %s";
			String[] args = StringUtils.split(tree.getChild(0).getChild(2).getText(), ",");
			if(args.length  == 2 ){
				String derivationNewExpr = String.format(newExpr, args[0],args[1],args[0]);
				tree = buildParseTree(derivationNewExpr,printTree);
				log.info(String.format("Derivation [%s] converted as -> %s", derivationStmt,derivationNewExpr));
			}
			//Trim(NULLTOVALUE
		}else if(StringUtils.startsWithIgnoreCase(derivationStmt, "Trim(NullToValue")){
			String newExpr = "If IsNull(Trim(%s)) then %s else %s";
			String[] args = StringUtils.split(tree.getChild(0).getChild(2).getChild(0).getChild(2).getText(), ",");			
			if(args.length  == 2 ){				
				String derivationNewExpr = String.format(newExpr, args[0],args[1],args[0]);
				//System.out.println("New Expr ->"+derivationNewExpr);
				tree = buildParseTree(derivationNewExpr,printTree);
				log.info(String.format("Derivation [%s] converted as -> %s", derivationStmt,derivationNewExpr));
			}
			//Trim(NULLTOVALUE
		}
		
		
		if(StringUtils.containsIgnoreCase(derivationStmt,"Else If") ){			
			//System.out.println("Error -->>>");
			throw new Exception("IF expr error for -->"+derivationStmt);
			/*RHExpression r = new RHExpression();
			r.setText("  ");
			r.setTypeDet("String_Value");
			r.setFuncArgType("VALUE");
			r.setFuncArgDataType("S");
			r.setType("Value");
			r.setParentId(visitorRHExprList.get(4).getParentId());
			r.setId(StringUtils.substringBefore(visitorRHExprList.get(4).getId(), "-")+RandomStringUtils.randomNumeric(5));
			r.setIndex(2);
			r.setDepth(2);
			visitorRHExprList.add(r);*/
		}

		// ParseTreeWalker walker=new ParseTreeWalker();

		// walker.walk(new DSDerivationSubStringListener(), tree);

		DSDerivationCustomVisitor visitor = new DSDerivationCustomVisitor();
		visitor.visit(tree);

		//LinkedHashMap<String, String> outStack = visitor.visitorStack;
		
		LinkedList<RHExpression> visitorRHExprList = visitor.visitorRHExprList;
		
		//if second one does not have 
		/**
		 *  "index": 0,
    "depth": 1,
		 */
		
		if(visitor.errorList.size() > 0){
			throw new Exception(StringUtils.join(visitor.errorList,"//"));
		}
		
if(visitorRHExprList.size() > 2){
			if( !(visitorRHExprList.get(1).getIndex() == 0 && visitorRHExprList.get(1).getDepth() == 1) ){
				throw new Exception("exprlist error for -->"+derivationStmt);
			}
		}
		
		if(visitorRHExprList.size() > 4 && StringUtils.equalsIgnoreCase(visitorRHExprList.get(1).getText(),"CONCATENATE")){				
			throw new Exception("CONCATENATE expr error for -->"+derivationStmt);
		}
		
		
		
		
		
		//FilesUtil.createFile("output/if_else_if.json", gson.toJson(visitorRHExprList));

		return visitorRHExprList;
	}

	/**
	 * @param args
	 * @return 
	 */
	public static LinkedList<RHExpression> parseDerivation(String derivationStmt) throws Exception {
		
		return parseDerivation(derivationStmt,false);

	}

	/**
	 * @param derivationStmt
	 * @return
	 */
	public static ParseTree buildParseTree(String derivationStmt, boolean printTree) {
		ANTLRInputStream input = new ANTLRInputStream(derivationStmt);
		DSDerivationGrammarLexer lexer = new DSDerivationGrammarLexer(input);
		CommonTokenStream tokens = new CommonTokenStream(lexer);
		DSDerivationGrammarParser parser = new DSDerivationGrammarParser(tokens);
		parser.setBuildParseTree(true);
		parser.setErrorHandler(new BailErrorStrategy());
		parser.addErrorListener(DescriptiveErrorListener.INSTANCE);

		ParseTree tree = parser.statement();
		if(printTree){
			System.out.println("AST tree -->>>  " + tree.toStringTree(parser));
		}else{
			log.info("AST tree -->>>  " + tree.toStringTree(parser));
		}
		return tree;
	}

}
