/**
 * 
 */
package com.citi.gcg.ds.parser.visitor;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Stack;
import java.util.TreeMap;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.misc.NotNull;
import org.antlr.v4.runtime.tree.TerminalNodeImpl;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarBaseVisitor;
import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarParser;
import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarParser.LiteralContext;
import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarParser.NameContext;
import com.citi.gcg.ds.parser.grammar.DSDerivationGrammarParser.PrimaryExprContext;
import com.citi.gcg.rh.beans.RHExpression;
import com.citi.gcg.rh.beans.Value;

/**
 * @author dosapati
 *
 */
public class DSDerivationCustomVisitor extends DSDerivationGrammarBaseVisitor<Value> {
	private static Logger log = LoggerFactory.getLogger(DSDerivationCustomVisitor.class);

	public LinkedHashMap<String, String> visitorStack = new LinkedHashMap<>();

	public LinkedList<RHExpression> visitorRHExprList = new LinkedList<>();
	
	public LinkedList<String> errorList = new LinkedList<>();

	Stack<String> idStack = new Stack<>();
	
	int depthNum = -1;
	
	
	
	 String idPrefix = "ext-";
			
	public  String generateIdPrefix(){
		StringBuilder sb = new StringBuilder("ext").append(RandomStringUtils.randomNumeric(4)).append("-");
		idPrefix = sb.toString();
		return sb.toString();
	}
	
	@Override
	public Value visitStatement(@NotNull DSDerivationGrammarParser.StatementContext ctx) {
		
		buildRootExpression();
		
		//generate id prefix ... first ..
		
		generateIdPrefix();
		
		StringBuilder sb = new StringBuilder();
		sb.append("<Statement>");
		//log.debug("child count -->"+ctx.getChild(0).getChild(0).getClass() + " ``` ->"+ctx.getChild(0).getChild(0).getText());
		
		if(ctx.getChild(0).getChild(0) instanceof LiteralContext || ctx.getChild(0).getChild(0) instanceof PrimaryExprContext || ctx.getChild(0).getChild(0) instanceof NameContext){
			String id = generateTreeId();
			idStack.push(id);
			depthNum++;
			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Function");
			
			expr.setTypeDet("ASSIGN");
			expr.setText("ASSIGN");
			expr.setDepth(depthNum);
			
			//log.debug("idStack --> "+idStack.size());
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(expr);
		}
		
		visitChilds(ctx, sb);
		sb.append("</Statement>");
		visitorStack.put("statement", sb.toString());
		return new Value(sb.toString());
	}

	private void buildRootExpression() {
		RHExpression rootExpr = new RHExpression();
		rootExpr.setFuncArgType("");
		rootExpr.setType("");
		
		rootExpr.setTypeDet("");
		rootExpr.setText("Start");
		rootExpr.setRoot(true);
		rootExpr.setFirst(true);
		rootExpr.setLast(true);
		rootExpr.setId("root");
		rootExpr.setDepth(0);
		rootExpr.setIndex(0);
		visitorRHExprList.add(rootExpr);
		idStack.push("root");
		depthNum++;
	}
	
	private int findNumOfParentIdOccurances(String parentId){
		int cnt = -1;
		if(!StringUtils.equalsIgnoreCase("root", parentId)){
			for (RHExpression expr : visitorRHExprList) {
				if(StringUtils.equalsIgnoreCase(expr.getParentId(), parentId)){
					cnt++;
				}
			}
		}		
		return cnt;
	}
  
	@Override
	public Value visitIf_then_else(@NotNull DSDerivationGrammarParser.If_then_elseContext ctx) {
		// ctx.expression()
		StringBuilder sb = new StringBuilder();
		sb.append("<if_then_else>");
		int childCount = ctx.getChildCount();
		
		for (int i = 0; i < childCount; i++) {
			if (!(ctx.getChild(i) instanceof TerminalNodeImpl)) {
				//log.debug(ctx.getChild(i).getClass().getName());

				if (i == 1) {					
					RHExpression expr = new RHExpression();
					expr.setFuncArgType("FUN");
					expr.setType("Condition");
					expr.setTypeDet("IF");
					expr.setText("IF");
					expr.setLeaf(false);
					expr.setParentId(idStack.get(idStack.size()-2));
					expr.setId(idStack.peek());
					expr.setDepth(depthNum);					
					expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
					visitorRHExprList.add(expr);
					sb.append("<if>").append(visit(ctx.getChild(i))).append("</if>");
				} else if (i == 3) {
					
					sb.append("<then>").append(visit(ctx.getChild(i))).append("</then>");
				} else if (i == 5) {

					sb.append("<else>").append(visit(ctx.getChild(i))).append("</else>");
				}
				//log.debug("%%%%%%% \n\n" + ctx.getChild(i).getChild(0).getClass().getName() + "\n\n %%%%%%%");
				// visitorStack.put("if_expr_"+i,
				// visit(ctx.getChild(i)).asString());
			} else {
				if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "if")){
					//log.debug(ctx.getChild(i).getText());
				}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "then")){
					
				}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "else")){
					
				}
				//log.debug(ctx.getChild(i).getText());

				//log.debug("Terminal node -->" + ctx.getText());
			}

		}
		idStack.pop();
		sb.append("</if_then_else>");
		visitorStack.put("if_then_else", sb.toString());
		return new Value(sb.toString());
		// return visitChildren(ctx);
	}

	
	public String generateTreeId(){
		StringBuilder sb = new StringBuilder(this.idPrefix).append(RandomStringUtils.randomNumeric(5));
		return sb.toString();
		
	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>
	 * The default implementation returns the result of calling
	 * {@link #visitChildren} on {@code ctx}.
	 * </p>
	 */
	@Override
	public Value visitExpression(@NotNull DSDerivationGrammarParser.ExpressionContext ctx) {
		int childCount = ctx.getChildCount();
		StringBuilder sb = new StringBuilder();
		sb.append("<expression>");
		
		String id = generateTreeId();
		idStack.push(id);
		
		depthNum++;
		
		//log.debug("indexStack -->"+depthNum);
		//log.debug(String.format("expr  parentId - %s, id - %s", parentId,id));
		if(childCount>=5){
			if(StringUtils.equalsIgnoreCase(ctx.getChild(1).getText(), "[") && StringUtils.equalsIgnoreCase(ctx.getChild(5).getText(), "]")){
				RHExpression expr = new RHExpression();
				expr.setFuncArgType("Fun");
				expr.setType("Function");
				expr.setTypeDet("SUBSTRING");
				expr.setText("SUBSTRING");
				
				//log.debug("idStack --> "+idStack.size());
				expr.setParentId(idStack.get(idStack.size()-2));
				expr.setId(idStack.peek());
				expr.setDepth(depthNum);
				expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
				visitorRHExprList.add(expr);
			}
		}
		
		for (int i = 0; i < childCount; i++) {
			log.debug(" - expression -->["+i+" - "+ctx.getChild(i).getClass().getName()+"]"+ctx.getChild(i).getText());
			//log.info(" - expression -->["+i+" - "+ctx.getChild(i).getClass().getName()+"]"+ctx.getChild(i).getText());

			if (!(ctx.getChild(i) instanceof TerminalNodeImpl)) {
				//log.debug(ctx.getChild(i).getClass().getName());
				
				sb.append(visit(ctx.getChild(i)).asString());
				
				// visitorStack.put("expr_"+(exprCounter++),
				// visit(ctx.getChild(i)).asString());
			} else {
				log.debug(i+"~~"+ctx.getChild(i).getText());
				//log.info(i+"~~"+ctx.getChild(i).getText());
				if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "=")){
					log.debug("add equals function block..");
					RHExpression expr = new RHExpression();
					expr.setFuncArgType("FUN");
					expr.setType("Common");

					expr.setTypeDet("EQUALS");
					expr.setText("EQUALS");
					expr.setLeaf(false);
					expr.setParentId(idStack.get(idStack.size()-2));
					expr.setId(idStack.peek());
					expr.setDepth(depthNum);
					expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
					visitorRHExprList.add(visitorRHExprList.size()-1,expr);
					//visitorRHExprList.add(expr);
				}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), ":")){
					if(concatCount == 0){
						log.debug("add concat function block..");
						RHExpression expr = new RHExpression();
						expr.setFuncArgType("FUN");
						expr.setType("String");
	
						expr.setTypeDet("CONCATENATE");
						expr.setText("CONCATENATE");
						expr.setLeaf(false);
						expr.setParentId(idStack.get(idStack.size()-2));
						expr.setId(idStack.peek());
						expr.setDepth(depthNum);
						expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
						visitorRHExprList.add(1,expr);
						concatCount++;
					}
					//visitorRHExprList.add(expr);
				}
			}

			// visitorStack.put("expr_"+1, visit(ctx.getChild(i)).asString());

		}
		idStack.pop();
		
		depthNum--;
		
		sb.append("</expression>");
		//log.debug("expression --->" + sb.toString());
		return new Value(sb.toString());
	}
	int concatCount = 0;
	
	@Override
	public Value visitName(@NotNull DSDerivationGrammarParser.NameContext ctx) {
		String id = generateTreeId();
		/*idStack.push(id);
		depthNum++;*/
		RHExpression expr = new RHExpression();
		expr.setFuncArgDataType("S");
		expr.setFuncArgType("ATTRIBUTE");
		expr.setType("Parameter");
		expr.setTypeDet("Attribute");		
		expr.setText(cleanUpString(ctx.getText()));
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		expr.setDepth(depthNum);
		expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
		visitorRHExprList.add(expr);
		/*idStack.pop();
		depthNum--;*/
		//log.debug("visitStringLiteral" + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText()+" ~~~ "+expr.getDepth());
		Value v = new Value("<name>" + ctx.getText() + "</name>");
		return v;
	}

	/**
	 * @param ctx
	 * @param i
	 */
	private void buildNodeValExpressions(DSDerivationGrammarParser.Binary_operatorContext ctx, int i) {
		if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "=")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Common");

			expr.setTypeDet("EQUALS");
			expr.setText("EQUALS");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), ">")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Common");

			expr.setTypeDet("GREATER_THAN");
			expr.setText("GREATER_THAN");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), ">=")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Common");

			expr.setTypeDet("GREATER_THAN_EQUALS");
			expr.setText("GREATER_THAN_EQUALS");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "<=")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Common");

			expr.setTypeDet("LESS_THAN_EQUALS");
			expr.setText("LESS_THAN_EQUALS");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "<")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Common");

			expr.setTypeDet("LESS_THAN");
			expr.setText("LESS_THAN");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "-")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Number");

			expr.setTypeDet("SUBTRACT");
			expr.setText("SUBTRACT");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), "<>")){			
			RHExpression expr = new RHExpression();
			expr.setFuncArgType("FUN");
			expr.setType("Common");

			expr.setTypeDet("NOT_EQUALS");
			expr.setText("NOT_EQUALS");
			expr.setLeaf(false);
			expr.setParentId(idStack.get(idStack.size()-2));
			expr.setId(idStack.peek());
			expr.setDepth(depthNum);
			expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
			visitorRHExprList.add(visitorRHExprList.size()-1,expr);
			//visitorRHExprList.add(expr);
		}else if(StringUtils.equalsIgnoreCase(ctx.getChild(i).getText(), ":")){
			
				log.debug("add concat function block..");
				RHExpression expr = new RHExpression();
				expr.setFuncArgType("FUN");
				expr.setType("String");

				expr.setTypeDet("CONCATENATE");
				expr.setText("CONCATENATE");
				expr.setLeaf(false);
				expr.setParentId(idStack.get(idStack.size()-2));
				expr.setId(idStack.peek());
				expr.setDepth(depthNum);
				expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
				visitorRHExprList.add(visitorRHExprList.size()-1,expr);
				
		}
	}
	
	
	@Override
	public Value visitBinary_operator(@NotNull DSDerivationGrammarParser.Binary_operatorContext ctx) { 
		StringBuilder sb = new StringBuilder();
		buildNodeValExpressions(ctx, 0);
		sb.append("<binary_operator>").append(ctx.getText()).append("</binary_operator>");
		Value v = new Value(sb.toString());
		return v;		
	}
	
	public Value visitConcatenation_operator(@NotNull DSDerivationGrammarParser.Concatenation_operatorContext ctx) { 
		StringBuilder sb = new StringBuilder();
		sb.append("<concatenation_operator>").append(ctx.getText()).append("</concatenation_operator>");
		Value v = new Value(sb.toString());
		return v;		
	}
	
	


	/**
	 * {@inheritDoc}
	 *
	 * <p>
	 * The default implementation returns the result of calling
	 * {@link #visitChildren} on {@code ctx}.
	 * </p>
	 */
	@Override
	public Value visitSubstring(@NotNull DSDerivationGrammarParser.SubstringContext ctx) {

		/**
		 * funcArgType": "FUN",
		"expanded": true,
		"text": "SUBSTRING",
		"type": "Function",
		"typeDet": "SUBSTRING",
		 */
		RHExpression expr = new RHExpression();
		expr.setFuncArgType("Fun");
		expr.setType("Function");
		expr.setTypeDet("SUBSTRING");
		expr.setText("SUBSTRING");
		
		//log.debug("idStack --> "+idStack.size());
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		visitorRHExprList.add(expr);
		
		StringBuilder sb = new StringBuilder();
		visitChilds(ctx, sb);
		Value v = new Value(sb.toString());
		return v;
	}

	@Override
	public Value visitSubStringVarName(@NotNull DSDerivationGrammarParser.SubStringVarNameContext ctx) {

		// Value varName = visit(ctx.subStringVarName());

		// //log.debug("varName -->"+varName);

		Value v = new Value(ctx.getText());

		// //log.debug("start -->"+visit(ctx.getChild(2))+" length ~~~
		// >>> "+visit(ctx.getChild(4)));
		// //log.debug("visitor ~~ "+ctx.getRuleIndex()+"~~ depth
		// ->"+ctx.depth()+", ->"+ctx.getText()+" ->"
		// +ctx.getChild(0).getText()+" child 3 -->"+ctx.getChild(2).getText()+"
		// child 5 -->"+ctx.getChild(4).getText());
		return v;
	}

	@Override
	public Value visitInputLinkName(@NotNull DSDerivationGrammarParser.InputLinkNameContext ctx) {
		//log.debug("visitInputLinkName " + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());

		LinkedHashMap<String, String> output = new LinkedHashMap<>();
		output.put("inputLinkName", ctx.getText());
		visitorStack.put("inputLinkName", ctx.getText());
		Value v = new Value(ctx.getText());
		return v;
	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>
	 * The default implementation returns the result of calling
	 * {@link #visitChildren} on {@code ctx}.
	 * </p>
	 */
	@Override
	public Value visitColumnName(@NotNull DSDerivationGrammarParser.ColumnNameContext ctx) {

		//log.debug("visitColumnName " + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());
		visitorStack.put("columnName", ctx.getText());

		Value v = new Value(ctx.getText() );
		return v;
	}

	@Override
	public Value visitLiteral(@NotNull DSDerivationGrammarParser.LiteralContext ctx) {
		//log.debug("visitLiteral" + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());
		// Literal is exception and not adding any root tag here.. since only
		// interested in sub nodes..
		StringBuilder sb = new StringBuilder();
		visitChilds(ctx, sb);
		Value v = new Value(sb.toString());
		return v;
	}

	@Override
	public Value visitStringLiteral(@NotNull DSDerivationGrammarParser.StringLiteralContext ctx) {
		
		RHExpression expr = new RHExpression();
		expr.setFuncArgDataType("S");
		expr.setFuncArgType("VALUE");
		expr.setType("Value");
		expr.setTypeDet("String_Value");
		expr.setText(cleanUpString(ctx.getText()));
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		expr.setDepth(depthNum);
		expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
		visitorRHExprList.add(expr);
		
		//log.debug("visitStringLiteral" + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText()+" ~~~ "+expr.getDepth());
		Value v = new Value("<stringLiteral>" + ctx.getText() + "</stringLiteral>");
		return v;
	}
	
	@Override
	public Value visitCharacterLiteral(@NotNull DSDerivationGrammarParser.CharacterLiteralContext ctx) {
		
		RHExpression expr = new RHExpression();
		expr.setFuncArgDataType("S");
		expr.setFuncArgType("VALUE");
		expr.setType("Value");
		expr.setTypeDet("String_Value");
		expr.setText(cleanUpString(ctx.getText()));
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		expr.setDepth(depthNum);
		expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
		visitorRHExprList.add(expr);
		
		//log.debug("visitCharLiteral" + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText()+" ~~~ "+expr.getDepth());
		Value v = new Value("<stringLiteral>" + ctx.getText() + "</stringLiteral>");
		return v;
	}
	
	static Map<String,String> replaceStrs = new LinkedHashMap<>();
	
	static{
		replaceStrs.put("%dd%mmm%yyyy", "DDMONYYYY");
		replaceStrs.put("%yyyy%mm%dd", "YYYYMMDD");
		replaceStrs.put("%yyyy-%mm-%dd %hh:%nn:%ss", "YYYY-MM-DD hh:mi:ss");
	}
	
	
	
	public String cleanUpString(String s){
		if(StringUtils.startsWith(s, "'")){
			s = StringUtils.removeFirst(s, "'");
			s = StringUtils.removeEnd(s, "'");
		}else if(StringUtils.startsWith(s, "\"")){
			s = StringUtils.removeFirst(s, "\"");
			s = StringUtils.removeEnd(s, "\"");
		}
		if(replaceStrs.containsKey(s)){
			s = replaceStrs.get(s);
		}
		//Is this the right logic , we still need to validate with RH team .. 
		if(StringUtils.isBlank(s.trim())){
			s = " ";
		}
		return s;
		
	}

	@Override
	public Value visitNumberLiteral(@NotNull DSDerivationGrammarParser.NumberLiteralContext ctx) {
		//log.debug("visitLiteral" + " ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());	
		
		RHExpression expr = new RHExpression();
		expr.setFuncArgDataType("N");
		expr.setFuncArgType("VALUE");
		expr.setType("Value");
		expr.setTypeDet("Numeric_Value");
		expr.setText(ctx.getText());
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		expr.setDepth(depthNum);
		expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
		visitorRHExprList.add(expr);
		Value v = new Value("<numberLiteral>" + ctx.getText() + "</numberLiteral>");
		return v;
	}

	@Override
	public Value visitPrimary(@NotNull DSDerivationGrammarParser.PrimaryContext ctx) {
		//log.debug("visitPrimary ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());
		Value v = new Value(ctx.getText());
		return v;
	}
	static Map<String,String> funcMapping = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
	static{
		funcMapping.put("IsNull", "IS_NULL");
		funcMapping.put("IsNotNull", "IS_NOT_NULL");
		funcMapping.put("UpCase", "UPPER");
		funcMapping.put("DateToString", "DATE_TO_STR");
		funcMapping.put("DateToString", "DATE_TO_STR");
		funcMapping.put("Trim", "TRIM");
		funcMapping.put("ASSIGN", "ASSIGN");
		funcMapping.put("EQUALS", "EQUALS");
		funcMapping.put("NOT_EQUALS", "NOT_EQUALS");
		funcMapping.put("GREATER_THAN", "GREATER_THAN");
		funcMapping.put("GREATER_THAN_EQUALS", "GREATER_THAN_EQUALS");
		funcMapping.put("LESS_THAN_EQUALS", "LESS_THAN_EQUALS");
		funcMapping.put("LESS_THAN", "LESS_THAN");
		funcMapping.put("LESS_THAN", "LESS_THAN");
		funcMapping.put("LOOKUP", "LOOKUP");
		funcMapping.put("StringToDate", "TO_DATE");
		funcMapping.put("StringToDecimal", "STR_TO_NUM");
		
	
	}
	
	

	@Override
	public Value visitFuncname(@NotNull DSDerivationGrammarParser.FuncnameContext ctx) {
		//log.debug("visitFuncname ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());
		/**
		 * "text": "IS_NOT_NULL", "typeDet": "IS_NOT_NULL", "funcArgType": "FUN",
		 * "leaf": false, "type": "Common",
		 */
		RHExpression expr = new RHExpression();
		expr.setFuncArgType("FUN");
		expr.setType("Common");
		
		if(StringUtils.isBlank(funcMapping.get(ctx.getText()))){
			
			errorList.add("Missing function for --->"+ctx.getText());
		}
		if(StringUtils.equalsIgnoreCase(funcMapping.get(ctx.getText()), "LOOKUP")){
			expr.setType("Function");
		}
		expr.setTypeDet(funcMapping.get(ctx.getText()));
		expr.setText(funcMapping.get(ctx.getText()));
		expr.setLeaf(false);
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		expr.setDepth(depthNum);
		expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
		visitorRHExprList.add(expr);
		Value v = new Value("<funcName>" + ctx.getText() + "</funcName>");
		return v;
	}

	public void visitChilds(ParserRuleContext ctx, StringBuilder sb) {

		int childCount = ctx.getChildCount();
		for (int i = 0; i < childCount; i++) {
			if (!(ctx.getChild(i) instanceof TerminalNodeImpl)) {
				sb.append(visit(ctx.getChild(i)));
				////log.debug(("visitPrimaryExpr - " + childCount) + " ~~~~ " + visit(ctx.getChild(i)));
			} else {

			}
		}

	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>
	 * The default implementation returns the result of calling
	 * {@link #visitChildren} on {@code ctx}.
	 * </p>
	 */
	@Override
	public Value visitPrimaryExpr(@NotNull DSDerivationGrammarParser.PrimaryExprContext ctx) {
		//log.debug("visitPrimaryExpr ~~ " + ctx.getRuleIndex() + "~~~~ " + ctx.getText());
		StringBuilder sb = new StringBuilder();
		sb.append("<primaryExpr>");
		int childCount = ctx.getChildCount();
		RHExpression expr = new RHExpression();
		expr.setFuncArgType("ATTRIBUTE");
		expr.setType("Parameter");
		expr.setTypeDet("Attribute");
		expr.setParentId(idStack.get(idStack.size()-2));
		expr.setId(idStack.peek());
		expr.setDepth(depthNum);
		expr.setIndex(findNumOfParentIdOccurances(expr.getParentId())+1);
		for (int i = 0; i < childCount; i++) {
			if (!(ctx.getChild(i) instanceof TerminalNodeImpl)) {
				Value v = visit(ctx.getChild(i));
				if(i == 0){
					expr.get_otherAttrMap().put("_inputLinkName", v.asString());
				}else if (i ==2){
					expr.setText(v.asString());
				}
				sb.append(v.asString());
				////log.debug(("visitPrimaryExpr ["+i+"]  - " + childCount) + " ~~~~ " + visit(ctx.getChild(i)));
			} else {

			}
		}
		visitorRHExprList.add(expr);

		sb.append("</primaryExpr>");
		Value v = new Value(sb);
		return v;

	}

	/**
	 * {@inheritDoc}
	 *
	 * <p>
	 * The default implementation returns the result of calling
	 * {@link #visitChildren} on {@code ctx}.
	 * </p>
	 */
	@Override
	public Value visitArguments(@NotNull DSDerivationGrammarParser.ArgumentsContext ctx) {
		// //log.debug("visitArguments ~~ "+ctx.getRuleIndex()+"~~~~
		// "+ctx.getText());
		int childCount = ctx.getChildCount();
		StringBuilder sb = new StringBuilder();

		sb.append("<arguments>");
		for (int i = 0; i < childCount; i++) {
			if (!(ctx.getChild(i) instanceof TerminalNodeImpl)) {
				sb.append(visit(ctx.getChild(i)));
				////log.debug(("visitPrimaryExpr - " + childCount) + " ~~~~ " + visit(ctx.getChild(i)));
			} else {

			}
			////log.debug(("visitArguments -" + childCount) + "~~~~" + visit(ctx.getChild(i)));
		}
		sb.append("</arguments>");
		Value v = new Value(sb.toString());
		return v;

	}

}
