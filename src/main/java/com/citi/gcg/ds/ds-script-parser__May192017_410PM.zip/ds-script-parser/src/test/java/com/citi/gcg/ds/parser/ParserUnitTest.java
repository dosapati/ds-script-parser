/**
 * 
 */
package com.citi.gcg.ds.parser;


import java.util.LinkedList;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;

import com.citi.gcg.ds.parser.grammar.util.DSDerivationGrammarUtil;
import com.citi.gcg.ds.util.FilesUtil;
import com.citi.gcg.rh.beans.RHExpression;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

/**
 * @author dosapati
 *
 */
public class ParserUnitTest {
	
	final static Gson gson = new GsonBuilder().setPrettyPrinting().serializeNulls().create();


	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {

			  String SPACE = " ";

			System.out.println("ABC... !");

			String s1 = "If IsNull(Tfm_Standardize.CHRG_OFF_DT) then '' else UpCase(DateToString(Tfm_Standardize.CHRG_OFF_DT,'%dd%mmm%yyyy'))";
			String s20 = "If IsNotNull(Tfm_Standardize.CHRG_OFF_DT) Then '2' Else ('') ";
			String s21 = "If Lnk_Nxg_Data.ADQ_TOT_DPD_CNT > 0 then 'Y' else 'N'";
			String s22 = "If Lnk_Nxg_Data.CURRDELQPFOM >=1 then Lnk_Nxg_Data.CURRDELQPFOM-1 else 0";
			String s23 = "if Isnull(Jn_Tfm_Standardize.CURR_DELQ_PFOM) Or Trim(Jn_Tfm_Standardize.CURR_DELQ_PFOM)[1,1]='' or Trim(Jn_Tfm_Standardize.CURR_DELQ_PFOM)[1,1]=' ' THEN 0 ELSE Trim(Jn_Tfm_Standardize.CURR_DELQ_PFOM)[1,1]";
			String s25 = "ASSIGN(LOOKUP('ROBO_PH_ACCOUNT_F_CCAR4_1_RULE_LK_0','A'))";
			String s26 = "A.FEED_FILE_TYP=2";
			String s27 = "A:B:'C'";
			String s28  = "a.FEED_ID:\":\":a.SRC_SYS_ACCT_NBR";
			String s291  = "''";
			String s31 = "NullToValue(Lnk_PrdSnp_xfm.FAIR_VAL_LVL_CDE,'NUL')";
			String s32 =   "If (IsNull(Lnk_Lkp_Tfm.ACTG_UNIT_ID) Or Lnk_Lkp_Tfm.ACTG_UNIT_ID=0) Then 9999 Else Lnk_Lkp_Tfm.ACTG_UNIT_ID";
			String s222 = "FEED_ID";
			String s333 ="If  (SVACCTPRIMBLKCDE) = \"W\" OR  (SVACCTINTRNLSTACDE) =\"Z\"\n" + 
					"Then '9' ELSE IF  (SVACCTINTRNLSTACDE ='A' or SVACCTINTRNLSTACDE= 'D' or SVACCTINTRNLSTACDE= 'I' or SVACCTINTRNLSTACDE= 'N') and (stgactblkcde1 <>'A' and stgactblkcde1<> 'F' and stgactblkcde1<> 'W') and (stgactblkcde2 <>'A' and stgactblkcde2<> 'F' and stgactblkcde2<> 'W') and Baltyp265 > 0.0 THEN '0' ELSE '3'";
			String s41 = "If (SVACCTPRIMBLKCDE) = \"W\" OR (SVACCTINTRNLSTACDE) =\"Z\" Then '9' ELSE IF (SVACCTINTRNLSTACDE ='A' or SVACCTINTRNLSTACDE= 'D' or SVACCTINTRNLSTACDE= 'I' or SVACCTINTRNLSTACDE= 'N') and (stgactblkcde1 <>'A' and stgactblkcde1<> 'F' and stgactblkcde1<> 'W') and (stgactblkcde2 <>'A' and stgactblkcde2<> 'F' and stgactblkcde2<> 'W') and Baltyp265 > 0.0 THEN '0' ELSE '3'";
			String s42 = "If Lnk_Nxg_Data.LOB_CDE = \"CRD-ALS-RW\" Then SetNull() Else  Lnk_Nxg_Data.ORA762";
			String s43  = "if IsNull(Jn_Tfm_Standardize.ACCT_PRIM_BLK_CDE) then '' Else (Jn_Tfm_Standardize.ACCT_BLK_CDE_1[1,1])";
			String s44 = "StringToDate(V_MISDATE,'%yyyy%mm%dd')";
			String s45 = "ISO_CNTRY_CD: PP_NAME : PROD_TYPE : Lnk_Max_Proc_id.SEQ_NBR : V_MISDATE";
			String s451 = "If IsNotNull(Lnk_Lkp_Tfm.GOC_REF_NBR) Then Lnk_Lkp_Tfm.GOC_REF_NBR Else If IsNotNull(Lnk_Lkp_Tfm.GOC_ID_RC) Then Lnk_Lkp_Tfm.GOC_ID_RC Else SetNull()";
			//If IsNotNull(Tfm_Standardize.ACCOUNT_NUMBER) Then Tfm_Standardize.ACCOUNT_NUMBER Else If IsNotNull(Tfm_Standardize.CHRG_OFF_DT) Then Tfm_Standardize.CHRG_OFF_DT Else SetNull()
			String s3333 = "IF ISNULL(Lnk_Casa_Mstr_Tfm.SRC_SYS_CSI_ID) THEN 161604 ELSE (StringToDecimal(trim(Lnk_Casa_Mstr_Tfm.SRC_SYS_CSI_ID)))";
			String s47 = "'  '";
			String s46 = "'A':'B':'C':'D'";
			String s33 = "StringToDate(V_MISDATE)";
			String s34 = "Trim(NULLTOVALUE(Lnk_Ds_Tfm.ACCT_SRC_STAT_CDE,'NUL'))";
			String s29 = "Trim(FEED_ID):':': Trim(DSLink158.ACCT_NO)";
			String s = "Tfm_Standardize.REPORTING_PERIOD [1,6]";
			String s6 = "If IsNull(Lnk_Jn_To_Tfm.LAST_FUNDS_ADVANCED_DATE) Then '' Else (Lnk_Jn_To_Tfm.LAST_FUNDS_ADVANCED_DATE)";
			String s5 = "'0.0'";
			String s4 = "If IsNull(Lnk_Nxg_Data.CCL_AMOUNT) then '' else If Index(DecimalToString(Lnk_Nxg_Data.CCL_AMOUNT,\"suppress_zero\"), '.',1)=0 THEN \n" + 
					"DecimalToString(Lnk_Nxg_Data.CCL_AMOUNT,\"suppress_zero\") : '.0' ELSE DecimalToString(Lnk_Nxg_Data.CCL_AMOUNT,\"suppress_zero\")";
			String expr = s.replaceAll("[\\t\\n\\r]",SPACE).trim().replaceAll("( )+",SPACE);
			System.out.println("expr ---> "+expr);
			
			LinkedList<RHExpression> dlList = DSDerivationGrammarUtil.parseDerivation(s,true);
			boolean isConcat = false;
			System.out.println("dlList -->>>"+dlList.size());
			if(StringUtils.equalsIgnoreCase(dlList.get(1).getText(),"IF") &&  dlList.size() == 5 ){			
				//System.out.println("Error -->>>");
				RHExpression r = new RHExpression();
				r.setText("  ");
				r.setTypeDet("String_Value");
				r.setFuncArgType("VALUE");
				r.setFuncArgDataType("S");
				r.setType("Value");
				r.setParentId(dlList.get(4).getParentId());
				r.setId(StringUtils.substringBefore(dlList.get(4).getId(), "-")+RandomStringUtils.randomNumeric(5));
				r.setIndex(2);
				r.setDepth(2);
				dlList.add(r);
				/**
				 * {
    "text": "ELSE",
    "typeDet": "String_Value",
    "funcArgType": "VALUE",
    "funcArgDataType": "S",
    "type": "Value",
    "id": "ext1464-32110",
    "parentId": "ext1464-46513",
    "root": false,
    "isFirst": false,
    "isLast": false,
    "index": 2,
    "depth": 2,
    "children": [],
    "visible": true,
    "leaf": false,
    "_inputLinkName": null,
    "_otherAttrMap": {},
    "rec": null
  }
				 */
				/*if(StringUtils.countMatches(s, ":") == 4 ){
					int cnt = -1;
					int index = 1;
					for (RHExpression rhExpression : dlList) {
						cnt++;
						if(cnt > 2){
							rhExpression.setIndex(index++);
							rhExpression.setDepth(2);
						}
					}
				}*/
			}

			//ParseTree tree = DSDerivationGrammarUtil.buildParseTree(s);

			//System.out.println("tree " + tree.toStringTree(parser));

			// ParseTreeWalker walker=new ParseTreeWalker();

			// walker.walk(new DSDerivationSubStringListener(), tree);

			
			
			

			/*Set<Entry<String, String>> outEntrySet = outStack.entrySet();
			// System.out.println(tree);
			for (Entry<String, String> entry : outEntrySet) {
				System.out.println(entry.getKey() + " #### " + entry.getValue());
			}*/
			
			FilesUtil.createFile("output/if_else_if.json", gson.toJson(dlList));

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();

			System.out.println("QQQ1 " + e.getMessage());
		}

		/**
		 * while​ ( expr!=​null​ ) { ​// while we have more expressions​ ​ ​//
		 * create new lexer and token stream for each line (expression)​ ​
		 * ANTLRInputStream input = ​new​ ANTLRInputStream(expr+​"\n"​); ​ ExprLexer
		 * lexer = ​new​ ExprLexer(input); ​ lexer.setLine(line); ​// notify lexer
		 * of input position​ ​ lexer.setCharPositionInLine(0); ​ CommonTokenStream
		 * tokens = ​new​ CommonTokenStream(lexer); ​ parser.setInputStream(tokens);
		 * ​// notify parser of new token stream​ ​ parser.stat(); ​// start the
		 * parser​ ​ expr = br.readLine(); ​// see if there's another line​ ​
		 * line++; ​ }
		 */

	}

}
